namespace AppHotel_Agenda13.Models;

public class Reserva
{
    public DateTime Entrada { get; set; }
    public DateTime Saida { get; set; }
    public string Quarto { get; set; } = string.Empty;
    public int Hospedes { get; set; }
    public string Descricao => $"{Quarto} • {Hospedes} hóspede(s)\n{Entrada:dd/MM/yyyy} até {Saida:dd/MM/yyyy}";
}
