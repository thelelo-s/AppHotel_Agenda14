using System.Collections.ObjectModel;

namespace AppHotel_Agenda13.Models;

public static class ReservaStore
{
    public static ObservableCollection<Reserva> Reservas { get; } = new();
}
