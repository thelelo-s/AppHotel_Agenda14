using AppHotel_Agenda13.Models;

namespace AppHotel_Agenda13.Pages;

public partial class HomePage : ContentPage
{
    private readonly ReservaViewModel _viewModel = new();

    public HomePage()
    {
        InitializeComponent();
        BindingContext = _viewModel;
    }

    private async void OnConsultarClicked(object sender, EventArgs e)
    {
        if (_viewModel.DataEntrada.Date < DateTime.Today)
        {
            await DisplayAlert("Data inválida", "A entrada não pode ser anterior a hoje.", "OK");
            return;
        }
        if (_viewModel.DataSaida.Date <= _viewModel.DataEntrada.Date)
        {
            await DisplayAlert("Data inválida", "A saída precisa ser depois da entrada.", "OK");
            return;
        }
        if (string.IsNullOrWhiteSpace(_viewModel.TipoQuarto) || _viewModel.QuantidadeHospedes < 1)
        {
            await DisplayAlert("Dados incompletos", "Selecione um quarto e a quantidade de hóspedes.", "OK");
            return;
        }
        ReservaStore.Reservas.Add(new Reserva
        {
            Entrada = _viewModel.DataEntrada,
            Saida = _viewModel.DataSaida,
            Quarto = _viewModel.TipoQuarto,
            Hospedes = _viewModel.QuantidadeHospedes
        });
        await DisplayAlert("Reserva registrada", "Reserva de demonstração salva! Confira a aba Minhas reservas.", "OK");
    }
}
