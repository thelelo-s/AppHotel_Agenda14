using AppHotel_Agenda13.Models;

namespace AppHotel_Agenda13.Pages;

public partial class ReservasPage : ContentPage
{
    public ReservasPage()
    {
        InitializeComponent();
        BindingContext = ReservaStore.Reservas;
    }
}
