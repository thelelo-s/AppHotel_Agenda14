# App Hotel — Agenda 14 (ETEC)

Projeto .NET MAUI para Windows, adaptado do App Hotel da Agenda 13.

## Alterações
- Nova paleta azul, títulos e textos personalizados.
- Data de entrada e data de saída, com validação no botão de reserva.
- Nova tela **Minhas reservas**, com lista em memória usando `ObservableCollection<Reserva>`.
- Tela **Sobre** com desenvolvedor Théo Henrique e ano de 2026.

## Executar
Abra `AppHotel_Agenda14.csproj` no Visual Studio 2026 com a carga de trabalho .NET MAUI e o SDK .NET 10. Selecione o projeto e pressione F5. O alvo é Windows.

## Evidências
Capture imagens reais da tela Reservar, da tela Minhas reservas (após confirmar uma reserva) e da tela Sobre. Envie as capturas ao professor e o link do repositório GitHub com os arquivos e pastas do projeto.

Este projeto é uma demonstração acadêmica: não realiza reservas reais e os dados não são persistidos ao fechar o aplicativo.
